#!/bin/bash
# properties = {properties}
{exec_job}
